<?php

// Redirecciona la pagina
header('Location: ../');

// Cierra la pagina
exit;

?>