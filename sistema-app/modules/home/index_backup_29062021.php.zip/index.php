<?php require_once show_template('header-advanced'); ?>
<div class="panel-heading">
	<h3 class="panel-title">
		<span class="glyphicon glyphicon-option-vertical"></span>
		<strong>Escritorio</strong>
	</h3>
</div>
<style>
.medida{
	height:300px;
	overflow:scroll;
}
.medida2{
	height:200px;
	overflow:scroll;
}	
</style>
<div class="panel-body">
	<div class="row">
		<div class="col-sm-4 col-md-3">
			<div class="row margin-bottom">
				<div class="col-xs-10 col-xs-offset-1">
					<img src="<?= imgs . '/logo-color.png'; ?>" class="img-responsive">
				</div>
			</div>
			<div class="well text-center">
				<?php if ($_user['persona_id']) : ?>
				<h4 class="margin-none">Bienvenido al sistema!</h4>
				<p>
					<strong><?= escape($_user['nombres'] . ' ' . $_user['paterno'] . ' ' . $_user['materno']); ?></strong>
				</p>
				<?php else : ?>
				<h4 class="margin-none">Bienvenido al sistema!</h4>
				<p>
					<strong><?= escape($_user['username']); ?></strong>
				</p>
				<?php endif ?>
				<p>
					<img src="<?= ($_user['avatar'] == '') ? imgs . '/avatar.jpg' : profiles . '/' . $_user['avatar']; ?>" class="img-circle" width="128" height="128" data-toggle="modal" data-target="#modal_mostrar">
				</p>
				<p class="margin-none">
					<strong><?= escape($_user['email']); ?></strong>
					<br>
					<span class="text-success">en línea</span>
				</p>
			</div>
			<div class="list-group">
				<a href="../sistema-app/storage/AppNexcorpDistribucion.apk" class="list-group-item">
					<span>Descargar aplicacion <b>PreventasApp</b></span>
				</a>
				<a href="?/home/perfil_ver" class="list-group-item">
					<span>Mostrar mi perfil</span>
					<span class="glyphicon glyphicon-menu-right pull-right"></span>
				</a>
				<a href="?/site/logout" class="list-group-item">
					<span>Cerrar mi sesión</span>
					<span class="glyphicon glyphicon-menu-right pull-right"></span>
				</a>
			</div>
		</div>
		<div class="col-sm-8 col-md-9">
			<div class="panel panel-warning">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span class="glyphicon glyphicon-search"></span>
                        <strong>Fecha de vencimiento cercana</strong>
                    </h3>
                </div>
                <div class="panel-body">
                    <?php
                    // $almacen = $db->from('inv_almacenes')->where('principal', 'S')->fetch_first();
                    // $id_almacen = ($almacen) ? $almacen['id_almacen'] : 0;
                    $productosv = $db->query("
                					SELECT * FROM (SELECT DATE(DATE_ADD(now(), INTERVAL 11 MONTH)) as nueva_fecha, p.id_producto, p.promocion, p.descripcion, p.imagen, p.codigo, p.nombre_factura as nombre, p.nombre_factura, p.cantidad_minima, p.precio_actual, IFNULL(e.cantidad_ingresos, 0) AS cantidad_ingresos, IFNULL(s.cantidad_egresos, 0) AS cantidad_egresos, (IFNULL(e.cantidad_ingresos, 0) - IFNULL(s.cantidad_egresos, 0)) AS cantidad_total, u.unidad, u.sigla, c.categoria, e.vencimiento2, e.detalles_ingreso, s.detalles_egreso
					FROM inv_productos p
					LEFT JOIN (SELECT d.producto_id, SUM(d.cantidad) AS cantidad_ingresos, MIN(d.vencimiento) as vencimiento2, GROUP_CONCAT(i.id_ingreso, '*', d.cantidad, '*', d.vencimiento ORDER BY i.id_ingreso ASC SEPARATOR '|' ) as detalles_ingreso
						   FROM inv_ingresos_detalles d
						   LEFT JOIN inv_ingresos i ON i.id_ingreso = d.ingreso_id
						   -- WHERE i.almacen_id = '$id_almacen'
						   GROUP BY d.producto_id) AS e ON e.producto_id = p.id_producto
					LEFT JOIN (SELECT d.producto_id, SUM(IF(e.tipo = 'Preventa' && e.preventa = 'habilitado', d.cantidad, IF(e.tipo='No venta' && e.estadoe = 4, d.cantidad, IF(e.tipo NOT IN ('Preventa', 'No venta'), d.cantidad, 0)))) AS cantidad_egresos, GROUP_CONCAT(e.id_egreso, '*', d.cantidad ORDER BY e.id_egreso ASC SEPARATOR '|' ) as detalles_egreso
						   FROM inv_egresos_detalles d LEFT JOIN inv_egresos e ON e.id_egreso = d.egreso_id
						   -- WHERE e.almacen_id = '$id_almacen'
						   GROUP BY d.producto_id) AS s ON s.producto_id = p.id_producto
					LEFT JOIN inv_unidades u ON u.id_unidad = p.unidad_id
                    LEFT JOIN inv_categorias c ON c.id_categoria = p.categoria_id) as ct WHERE ct.cantidad_total != 0 AND ct.vencimiento2 < ct.nueva_fecha
                					")->fetch();
                    ?>
                    <div class="table-responsive medida2" id="medida2">
                        <table id="productos" class="table table-bordered table-condensed table-striped table-hover table-xs">
                            <thead>
                            <tr class="active">
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">#</th>
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Código</th>
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Nombre comercial</th>
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Nombre genérico</th>
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Stock</th>
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Vencimiento</th>
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Almacen</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($productosv as $nro => $producto) { ?>

                                <?php
                                $detalle_ingreso = explode('|',$producto['detalles_ingreso']);
                                $detalle_egreso = explode('|',$producto['detalles_egreso']);
                                $sw = 0;
                                $mostrar = '';
                                for($i = 0; $i < count($detalle_ingreso); $i ++){
                                    if($sw == 0){
                                        $valor1 = explode('*',$detalle_ingreso[$i]);
                                        $canti = $valor1[1];
                                        $venci = $valor1[2];
                                        foreach($detalle_egreso as $valores2){
                                            $valor2 = explode('*',$valores2);
                                            if($canti >= $valor2[1]){
                                                $canti = $canti - $valor2[1];
                                            }else{
                                                $i = $i + 1;
                                                $valor1 = explode('*',$detalle_ingreso[$i]);
                                                $canti = $canti + $valor1[1];
                                                $venci = $valor1[2];
                                                if($canti > $valor2[1]){
                                                    $canti = $canti - $valor2[1];
                                                }else{
                                                    $i = $i + 1;
                                                    $valor1 = explode('*',$detalle_ingreso[$i]);
                                                    $canti = $canti + $valor1[1];
                                                    $venci = $valor1[2];
                                                    if($canti > $valor2[1]){
                                                        $canti = $canti - $valor2[1];
                                                    }else{
                                                        $i = $i + 1;
                                                        $valor1 = explode('*',$detalle_ingreso[$i]);
                                                        $canti = $canti + $valor1[1];
                                                        $venci = $valor1[2];
                                                        if($canti > $valor2[1]){
                                                            $canti = $canti - $valor2[1];
                                                        }else{
                                                            $i = $i + 1;
                                                            $valor1 = explode('*',$detalle_ingreso[$i]);
                                                            $canti = $canti + $valor1[1];
                                                            $venci = $valor1[2];
                                                            if($canti > $valor2[1]){
                                                                $canti = $canti - $valor2[1];
                                                            }else{
                                                                $i = $i + 1;
                                                                $valor1 = explode('*',$detalle_ingreso[$i]);
                                                                $canti = $canti + $valor1[1];
                                                                $venci = $valor1[2];
                                                                if($canti > $valor2[1]){
                                                                    $canti = $canti - $valor2[1];
                                                                }else{
                                                                    $i = $i + 1;
                                                                    $valor1 = explode('*',$detalle_ingreso[$i]);
                                                                    $canti = $canti + $valor1[1];
                                                                    $venci = $valor1[2];
                                                                    if($canti > $valor2[1]){
                                                                        $canti = $canti - $valor2[1];
                                                                    }else{

                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        $sw = 1;
                                        if($canti > 0){
                                            $mostrar = $mostrar.' ('.$canti.') '.$venci.'<br>';
                                        }
                                    }else{
                                        $valor1 = explode('*',$detalle_ingreso[$i]);
                                        $canti = $valor1[1];
                                        $venci = $valor1[2];
                                        $mostrar = $mostrar.' ('.$canti.') '.date_decode($venci, $_institution['formato']).'<br>';
                                    }
                                }

                                $fecha_vencimiento = $producto['vencimiento2'];
                                $fecha_actual = date('d-m-Y');

                                $datetime1 = date_create($fecha_actual);
                                $datetime2 = date_create($fecha_vencimiento);
                                $interval = date_diff($datetime1, $datetime2);
                                $interval = $interval->format('%R%a');
                                $interval = str_replace("+", "", $interval);
                                $stock = $producto['cantidad_ingresos'] - $producto['cantidad_egresos'];
                                if ($interval <= 90 && $stock != 0) {
                                    $fecha_vencimiento = date('d-m-Y', strtotime($producto['vencimiento2']));
                                    ?>
                                    <tr>
                                        <td><?= $nro + 1; ?></td>
                                        <td><?= $producto['codigo']; ?></td>
                                        <td><?= $producto['nombre']; ?></td>
                                        <td><?= $producto['nombre_factura']; ?></td>
                                        <td><?= $stock;?> </td>
                                        <td class="text-nowrap"><?= $mostrar; ?></th>
                                        <td><?= $almacen['almacen'];?> </td>
                                        
                                    </tr>
                                    <?php
                                    // }
                                }
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
	
	<div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span class="glyphicon glyphicon-search"></span>
                        <strong>Productos vencidos</strong>
                    </h3>
                </div>
                <div class="panel-body">
                    <?php
                    $productos = $db->query("SELECT p.*, id.vencimiento, id.lote, id.lote_cantidad, a.almacen
                                FROM inv_productos p
                                LEFT JOIN inv_ingresos_detalles id ON p.id_producto = id.producto_id
                                LEFT JOIN inv_ingresos i ON id.ingreso_id = i.id_ingreso
                                LEFT JOIN inv_almacenes a ON i.almacen_id = a.id_almacen
                                WHERE id.lote_cantidad > 0
                                AND id.vencimiento <= CURDATE()
                                ORDER BY fecha_registro DESC, id_producto DESC LIMIT 20")->fetch();
                    ?>
                    <?php if ($productos) { ?>
                        <div class="table-responsive medida2" id="medida2">
                            <table id="productos" class="table table-bordered table-condensed table-striped table-hover table-xs">
                                <thead>
                                <tr class="active">
                                    <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">#</th>
                                    <th class="text-nowrap" style="width: 12%; background-color: #222; color:#fff; text-align: center; font-weight: bold;">Fecha vencimiento</th>
                                    <th class="text-nowrap" style="width: 22%; background-color: #222; color:#fff; text-align: center; font-weight: bold;">Nombre comercial</th>
                                    <th class="text-nowrap" style="width: 22%; background-color: #222; color:#fff; text-align: center; font-weight: bold;">Nombre genérico</th>
                                    <th class="text-nowrap" style="width: 12%; background-color: #222; color:#fff; text-align: center; font-weight: bold;">Cantidad actual</th>
                                    <th class="text-nowrap" style="width: 54%; background-color: #222; color:#fff; text-align: center; font-weight: bold;">Almacen</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($productos as $nro => $producto) { ?>
                                    <tr>
                                        <td><?= $nro + 1; ?></td>
                                        <td><?= date_decode($producto['vencimiento'], $_institution['formato']); ?></td>
                                        <td><?= $producto['nombre']; ?></td>
                                        <td><?= $producto['nombre_factura']; ?></td>
                                        <td><?= $producto['lote_cantidad']; ?></td>
                                        <td><?= $producto['almacen']; ?></td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    <?php } ?>
                </div>
            </div>
            
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span class="glyphicon glyphicon-search"></span>
                        <strong>Productos con bajo STOCK</strong>
                    </h3>
                </div>
                <div class="panel-body">
                    <?php

                    ?>
                    <div class="table-responsive medida2" id="medida2">

                        <table id="table" class="table table-bordered table-condensed table-striped table-hover table-xs">
                            <thead>
                            <tr class="active">
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">#</th>
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Código</th>
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Nombre comercial</th>
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Nombre genérico</th>
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Mínimo</th>
                                <th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Total existencias</th>
                                <!--<th class="text-nowrap" style="background-color: #222; color:#fff; text-align: center; font-weight: bold;">Almacen</th>-->
                            </tr>
                            </thead>
                        
                            <tbody>
                            <?php
                            $productos = $db->query("SELECT p.id_producto,p.asignacion_rol, p.descuento ,p.promocion,
						z.id_asignacion, z.unidad_id, z.unidade, z.cantidad2,z.id_roles,
						p.descripcion,p.imagen,p.codigo,p.nombre_factura as nombre,p.nombre_factura,p.cantidad_minima,p.precio_actual,
						IFNULL(e.cantidad_ingresos, 0) AS cantidad_ingresos, IFNULL(s.cantidad_egresos, 0) AS cantidad_egresos,
						u.unidad, u.sigla, c.categoria
					FROM inv_productos p
					LEFT JOIN (
						SELECT d.producto_id, SUM(d.cantidad) AS cantidad_ingresos
						FROM inv_ingresos_detalles d
						LEFT JOIN inv_ingresos i ON i.id_ingreso = d.ingreso_id
					    GROUP BY d.producto_id
					) AS e ON e.producto_id = p.id_producto
					LEFT JOIN (
						SELECT d.producto_id, SUM(IF(e.tipo = 'Preventa' && e.preventa = 'habilitado', d.cantidad, IF(e.tipo='No venta' && e.estadoe = 4, d.cantidad, IF(e.tipo NOT IN ('Preventa', 'No venta'), d.cantidad, 0)))) AS cantidad_egresos
						FROM inv_egresos_detalles d
						LEFT JOIN inv_egresos e ON e.id_egreso = d.egreso_id
						GROUP BY d.producto_id
					) AS s ON s.producto_id = p.id_producto
					LEFT JOIN inv_unidades u ON u.id_unidad = p.unidad_id
					LEFT JOIN inv_categorias c ON c.id_categoria = p.categoria_id
					LEFT JOIN (
						SELECT w.producto_id,
							GROUP_CONCAT(w.id_asignacion SEPARATOR '|') AS id_asignacion,
							GROUP_CONCAT(w.unidad_id SEPARATOR '|') AS unidad_id,
							GROUP_CONCAT(w.cantidad_unidad,')',w.unidad,':',w.otro_precio SEPARATOR '&') AS unidade,
							GROUP_CONCAT(w.cantidad_unidad SEPARATOR '*') AS cantidad2,
							GROUP_CONCAT(w.id_roles)AS id_roles
						FROM (
							SELECT q.*,u.*,s.id_roles
							FROM inv_asignaciones q
							LEFT JOIN inv_unidades u ON q.unidad_id = u.id_unidad
							LEFT JOIN (
								SELECT apr.asignacion_id,GROUP_CONCAT(apr.rol_id,'|',apr.asignacion_id)AS id_roles
								FROM inv_asignaciones_por_roles AS apr
								LEFT JOIN sys_roles AS r ON r.id_rol=apr.rol_id
								GROUP BY apr.asignacion_id
							)AS s ON s.asignacion_id=q.id_asignacion
							ORDER BY u.unidad DESC
						) w
						GROUP BY w.producto_id
					) z ON p.id_producto = z.producto_id")->fetch();
                            foreach ($productos as $nro => $producto) {
                                $ing = intval($producto['cantidad_ingresos']);
                                $egr = intval($producto['cantidad_egresos']);

                                if ($producto['cantidad_minima'] > ($ing - $egr)) {
                                    $almacen_id = $producto['almacen_id'];
                                    $almacen = $db->query("select almacen from inv_almacenes where id_almacen = '$almacen_id'");
                                    ?>
                                    <tr>
                                        <th class="text-nowrap"><?= $nro + 1; ?></th>
                                        <td class="text-nowrap"><?= escape($producto['codigo']); ?></td>

                                        <td class="width-lg"><?= escape($producto['nombre']); ?></td>
                                        <td class="width-lg"><?= escape($producto['nombre_factura']); ?></td>

                                        <td class="text-nowrap text-right"><?= escape($producto['cantidad_minima']); ?></td>
                                        <td class="text-nowrap text-right"><strong class="text-primary"><?php echo ($ing - $egr); ?></strong></td>
                                        <!--<td class="text-nowrap text-right"><?= $almacen['almacen']?></td>-->
                                    </tr>
                                <?php
                                }
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
	
		</div>
	</div>
</div>
<?php require_once show_template('footer-advanced'); ?>